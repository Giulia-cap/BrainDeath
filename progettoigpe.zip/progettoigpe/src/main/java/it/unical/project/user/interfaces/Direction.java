package it.unical.project.user.interfaces;


public enum Direction
{
    STOP, LEFT, RIGHT, UP, DOWN;
}