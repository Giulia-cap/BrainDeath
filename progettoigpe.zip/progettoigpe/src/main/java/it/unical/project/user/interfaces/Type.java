package it.unical.project.user.interfaces;

public enum Type 
{
	PLAYER,ZOMBIE,KEY,HOUSE,TREE,ROCK,WATER,BULLET
}
