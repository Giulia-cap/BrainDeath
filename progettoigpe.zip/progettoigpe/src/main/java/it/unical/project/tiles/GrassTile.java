package it.unical.project.tiles;

import it.unical.project.graphics.Assets;

public class GrassTile extends Tile {

	public GrassTile(int id) {
		super(Assets.grass, id);
	}

}
