package it.unical.project.user.interfaces;

public interface ClickListener {
	
	public void onClick();

}
